package com.nasstech.applock.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.nasstech.applock.ui.theme.ThemeColors
import kotlinx.coroutines.delay

/**
 * يدير شاشتي إنشاء وتأكيد PIN عبر انتقال أفقي بينهما.
 * عند فشل التطابق، تبقى الشاشة في خطوة التأكيد وتعرض رسالة خطأ مع أنيميشن اهتزاز،
 * ويُعاد المستخدم لخطوة الإنشاء فقط إذا رغب (لا تلقائيًا) لتجربة استخدام أوضح.
 */
@Composable
fun PinSetupScreen(
    colors: ThemeColors,
    onPinConfirmed: (String) -> Unit
) {
    var firstPin by remember { mutableStateOf<String?>(null) }
    var showError by remember { mutableStateOf(false) }
    var errorTick by remember { mutableStateOf(0) }

    LaunchedEffect(errorTick) {
        if (errorTick > 0) {
            showError = true
            delay(900)
            showError = false
        }
    }

    AnimatedContent(
        targetState = firstPin == null,
        transitionSpec = {
            slideInHorizontally { it } togetherWith slideOutHorizontally { -it }
        },
        label = "pin_setup_steps"
    ) { isCreateStep ->
        if (isCreateStep) {
            PinEntryScreen(
                title = "أنشئ رمز PIN",
                subtitle = "سيُستخدم هذا الرمز لفتح التطبيقات المقفولة",
                colors = colors,
                onComplete = { pin ->
                    firstPin = pin
                }
            )
        } else {
            PinEntryScreen(
                title = "أكّد رمز PIN",
                subtitle = "أعد إدخال الرمز للتأكيد",
                colors = colors,
                showError = showError,
                errorMessage = "الرمزان غير متطابقين، حاول مجددًا",
                onComplete = { pin ->
                    if (pin == firstPin) {
                        onPinConfirmed(pin)
                    } else {
                        errorTick++
                    }
                }
            )
        }
    }
}
