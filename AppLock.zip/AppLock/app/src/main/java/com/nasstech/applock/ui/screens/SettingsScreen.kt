package com.nasstech.applock.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nasstech.applock.ui.theme.AppTheme
import com.nasstech.applock.ui.theme.ThemeColors
import com.nasstech.applock.ui.theme.colorsFor

@Composable
fun SettingsScreen(
    colors: ThemeColors,
    currentTheme: AppTheme,
    useBiometric: Boolean,
    vibrationOn: Boolean,
    onThemeSelected: (AppTheme) -> Unit,
    onChangePinClick: () -> Unit,
    onBiometricToggle: (Boolean) -> Unit,
    onVibrationToggle: (Boolean) -> Unit,
    onBack: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(colors.gradientStart, colors.gradientEnd)))
            .systemBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع",
                        tint = colors.onSurface
                    )
                }
                Text(
                    text = "الإعدادات",
                    color = colors.onSurface,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }

            SectionTitle("المظهر", colors)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                items(AppTheme.entries.toList()) { theme ->
                    ThemeSwatch(
                        theme = theme,
                        isSelected = theme == currentTheme,
                        onClick = { onThemeSelected(theme) }
                    )
                }
            }

            SectionTitle("الأمان", colors)
            SettingsRow(
                icon = Icons.Filled.Lock,
                title = "تغيير رمز PIN",
                colors = colors,
                onClick = onChangePinClick
            )
            SettingsSwitchRow(
                icon = Icons.Filled.Fingerprint,
                title = "استخدام بصمة الإصبع",
                checked = useBiometric,
                colors = colors,
                onCheckedChange = onBiometricToggle
            )
            SettingsSwitchRow(
                icon = Icons.Filled.Vibration,
                title = "الاهتزاز",
                checked = vibrationOn,
                colors = colors,
                onCheckedChange = onVibrationToggle
            )

            SectionTitle("عن التطبيق", colors)
            SettingsRow(
                icon = Icons.Filled.Info,
                title = "AppLock — الإصدار 1.0",
                colors = colors,
                onClick = {}
            )
        }
    }
}

@Composable
private fun SectionTitle(text: String, colors: ThemeColors) {
    Text(
        text = text,
        color = colors.onSurface.copy(alpha = 0.55f),
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 18.dp, bottom = 4.dp)
    )
}

@Composable
private fun ThemeSwatch(
    theme: AppTheme,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val swatchColors = colorsFor(theme)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(swatchColors.gradientStart, swatchColors.gradientEnd)))
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            if (isSelected) {
                Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = "محدد",
                    tint = swatchColors.accent
                )
            }
        }
        Text(
            text = themeLabel(theme),
            color = colors.onSurface,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}

private fun themeLabel(theme: AppTheme): String = when (theme) {
    AppTheme.DARK -> "داكن"
    AppTheme.LIGHT -> "فاتح"
    AppTheme.PURPLE -> "بنفسجي"
    AppTheme.OCEAN -> "محيطي"
    AppTheme.SUNSET -> "غروب"
}

@Composable
private fun SettingsRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    colors: ThemeColors,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.surface.copy(alpha = 0.5f))
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = colors.accent)
        Text(
            text = title,
            color = colors.onSurface,
            fontSize = 15.sp,
            modifier = Modifier.padding(start = 14.dp)
        )
    }
    androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
}

@Composable
private fun SettingsSwitchRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    checked: Boolean,
    colors: ThemeColors,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.surface.copy(alpha = 0.5f))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = colors.accent)
            Text(
                text = title,
                color = colors.onSurface,
                fontSize = 15.sp,
                modifier = Modifier.padding(start = 14.dp)
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = colors.accent,
                checkedThumbColor = Color.White,
                uncheckedTrackColor = colors.dotEmpty
            )
        )
    }
    androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
}
