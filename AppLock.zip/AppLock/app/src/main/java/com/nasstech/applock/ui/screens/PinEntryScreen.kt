package com.nasstech.applock.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nasstech.applock.ui.components.PinDotsRow
import com.nasstech.applock.ui.components.PinKeypad
import com.nasstech.applock.ui.theme.ThemeColors

private const val PIN_LENGTH = 4

/**
 * شاشة عامة لإدخال PIN تُستخدم في 3 سياقات: إنشاء، تأكيد، وفتح القفل.
 *
 * @param title العنوان المعروض
 * @param subtitle الوصف الفرعي
 * @param colors ألوان الثيم الحالي
 * @param showBiometric إظهار زر البصمة (يُستخدم فقط في وضع فتح القفل)
 * @param showError تفعيل أنيميشن الاهتزاز وعرض رسالة الخطأ
 * @param onComplete يُستدعى عند اكتمال إدخال 4 أرقام، يرجع القيمة المدخلة
 * @param onBiometricClick يُستدعى عند الضغط على زر البصمة
 */
@Composable
fun PinEntryScreen(
    title: String,
    subtitle: String,
    colors: ThemeColors,
    showBiometric: Boolean = false,
    showError: Boolean = false,
    errorMessage: String = "",
    onComplete: (String) -> Unit,
    onBiometricClick: (() -> Unit)? = null,
    topRightAction: (@Composable () -> Unit)? = null
) {
    var pin by remember { mutableStateOf("") }
    var shakeTrigger by remember { mutableIntStateOf(0) }

    LaunchedEffect(showError) {
        if (showError) {
            shakeTrigger++
            pin = ""
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(colors.gradientStart, colors.gradientEnd))
            )
            .systemBarsPadding()
    ) {
        if (topRightAction != null) {
            Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.TopEnd) {
                topRightAction()
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp, vertical = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .padding(bottom = 24.dp)
                    .background(colors.accent.copy(alpha = 0.15f), CircleShape)
                    .padding(20.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = null,
                    tint = colors.accent,
                    modifier = Modifier.padding(0.dp)
                )
            }

            Text(
                text = title,
                color = colors.onSurface,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = subtitle,
                color = colors.onSurface.copy(alpha = 0.6f),
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 6.dp, bottom = 36.dp)
            )

            AnimatedContent(
                targetState = showError to errorMessage,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "error_message"
            ) { (isError, msg) ->
                Text(
                    text = if (isError) msg else " ",
                    color = colors.error,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            PinDotsRow(
                pinLength = pin.length,
                maxLength = PIN_LENGTH,
                colors = colors,
                shakeTrigger = shakeTrigger
            )

            Box(modifier = Modifier.padding(top = 48.dp)) {
                PinKeypad(
                    colors = colors,
                    onDigit = { digit ->
                        if (pin.length < PIN_LENGTH) {
                            pin += digit
                            if (pin.length == PIN_LENGTH) {
                                val finalPin = pin
                                onComplete(finalPin)
                                pin = ""
                            }
                        }
                    },
                    onBackspace = {
                        if (pin.isNotEmpty()) pin = pin.dropLast(1)
                    },
                    extraBottomLeftSlot = if (showBiometric && onBiometricClick != null) {
                        {
                            IconButton(onClick = onBiometricClick) {
                                Icon(
                                    imageVector = Icons.Filled.Fingerprint,
                                    contentDescription = "بصمة",
                                    tint = colors.accent,
                                    modifier = Modifier.padding(4.dp)
                                )
                            }
                        }
                    } else null
                )
            }
        }
    }
}
