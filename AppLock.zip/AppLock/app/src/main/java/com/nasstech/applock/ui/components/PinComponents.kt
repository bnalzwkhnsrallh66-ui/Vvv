package com.nasstech.applock.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nasstech.applock.ui.theme.ThemeColors
import kotlinx.coroutines.launch

/**
 * صف من النقاط يمثل عدد الأرقام المُدخلة من رمز PIN.
 * يهتز أفقيًا عند الخطأ (shake animation).
 */
@Composable
fun PinDotsRow(
    pinLength: Int,
    maxLength: Int,
    colors: ThemeColors,
    shakeTrigger: Int
) {
    val offsetX = remember { Animatable(0f) }

    LaunchedEffect(shakeTrigger) {
        if (shakeTrigger == 0) return@LaunchedEffect
        val keyframes = listOf(0f, -18f, 18f, -14f, 14f, -8f, 8f, 0f)
        for (target in keyframes) {
            offsetX.animateTo(target, animationSpec = tween(durationMillis = 45))
        }
    }

    Row(
        horizontalArrangement = Arrangement.spacedBy(18.dp),
        modifier = Modifier.offset(x = offsetX.value.dp)
    ) {
        repeat(maxLength) { index ->
            val filled = index < pinLength
            val animatedColor = remember { Animatable(colors.dotEmpty) }
            LaunchedEffect(filled, colors.accent, colors.dotEmpty) {
                animatedColor.animateTo(
                    if (filled) colors.accent else colors.dotEmpty,
                    animationSpec = tween(220)
                )
            }
            Box(
                modifier = Modifier
                    .size(if (filled) 18.dp else 16.dp)
                    .clip(CircleShape)
                    .background(animatedColor.value)
            )
        }
    }
}

/**
 * كيبورد رقمي دائري مخصص بأزرار من 0-9 + زر مسح + زر فاضي للتوازن البصري.
 */
@Composable
fun PinKeypad(
    colors: ThemeColors,
    onDigit: (String) -> Unit,
    onBackspace: () -> Unit,
    extraBottomLeftSlot: (@Composable () -> Unit)? = null
) {
    val rows = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9")
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        rows.forEach { row ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(28.dp)
            ) {
                row.forEach { digit ->
                    KeypadButton(text = digit, colors = colors) { onDigit(digit) }
                }
            }
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(28.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(72.dp),
                contentAlignment = Alignment.Center
            ) {
                extraBottomLeftSlot?.invoke()
            }
            KeypadButton(text = "0", colors = colors) { onDigit("0") }
            KeypadBackspaceButton(colors = colors, onClick = onBackspace)
        }
    }
}

@Composable
private fun KeypadButton(
    text: String,
    colors: ThemeColors,
    onClick: () -> Unit
) {
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScopeSafe()

    Box(
        modifier = Modifier
            .size(72.dp)
            .scale(scale.value)
            .clip(CircleShape)
            .background(colors.keyBackground)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                scope.launch {
                    scale.animateTo(0.85f, animationSpec = tween(60))
                    scale.animateTo(1f, animationSpec = spring(stiffness = Spring.StiffnessMedium))
                }
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = colors.keyText,
            fontSize = 26.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun KeypadBackspaceButton(
    colors: ThemeColors,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Filled.Backspace,
            contentDescription = "مسح",
            tint = colors.keyText
        )
    }
}

@Composable
private fun rememberCoroutineScopeSafe() = androidx.compose.runtime.rememberCoroutineScope()
