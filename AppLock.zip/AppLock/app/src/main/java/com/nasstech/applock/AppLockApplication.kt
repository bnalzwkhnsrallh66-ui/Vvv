package com.nasstech.applock

import android.app.Application
import com.nasstech.applock.data.AppLockRepository

class AppLockApplication : Application() {

    lateinit var repository: AppLockRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = AppLockRepository(applicationContext)
        // ذاكرة مؤقتة على مستوى التطبيق لتسجيل آخر تطبيق تم فتحه بنجاح
        // لمنع إعادة طلب الـ PIN فورًا عند العودة من شاشة القفل لنفس التطبيق
        UnlockSessionCache.clear()
    }
}

/**
 * كاش بسيط في الذاكرة يخزّن مؤقتًا (لمدة قصيرة) أن تطبيقًا معينًا
 * تم فتحه بنجاح، لتجنّب إعادة طلب الرمز عند كل تبديل سريع بين الشاشات
 * لنفس التطبيق (سلوك معتاد في تطبيقات App Lock الحقيقية).
 */
object UnlockSessionCache {
    private val unlockedUntil = mutableMapOf<String, Long>()
    private const val GRACE_PERIOD_MS = 5000L

    fun markUnlocked(packageName: String) {
        unlockedUntil[packageName] = System.currentTimeMillis() + GRACE_PERIOD_MS
    }

    fun isRecentlyUnlocked(packageName: String): Boolean {
        val until = unlockedUntil[packageName] ?: return false
        return System.currentTimeMillis() < until
    }

    fun clear() {
        unlockedUntil.clear()
    }
}
