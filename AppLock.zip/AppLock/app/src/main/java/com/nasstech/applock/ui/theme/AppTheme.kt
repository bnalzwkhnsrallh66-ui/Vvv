package com.nasstech.applock.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * يحتوي كل ثيم على مجموعة ألوان متدرجة تُستخدم في الخلفيات والأزرار والتأكيدات.
 */
enum class AppTheme(val id: String) {
    DARK("dark"),
    LIGHT("light"),
    PURPLE("purple"),
    OCEAN("ocean"),
    SUNSET("sunset");

    companion object {
        fun fromId(id: String): AppTheme = entries.find { it.id == id } ?: DARK
    }
}

data class ThemeColors(
    val gradientStart: Color,
    val gradientEnd: Color,
    val surface: Color,
    val onSurface: Color,
    val accent: Color,
    val accentSoft: Color,
    val dotEmpty: Color,
    val keyBackground: Color,
    val keyText: Color,
    val error: Color,
    val isDark: Boolean
)

fun colorsFor(theme: AppTheme): ThemeColors = when (theme) {
    AppTheme.DARK -> ThemeColors(
        gradientStart = Color(0xFF0F0F1E),
        gradientEnd = Color(0xFF1A1B3A),
        surface = Color(0xFF1E1F3D),
        onSurface = Color(0xFFF2F2FA),
        accent = Color(0xFF7B61FF),
        accentSoft = Color(0xFF5B4BCF),
        dotEmpty = Color(0xFF3A3B5C),
        keyBackground = Color(0xFF2A2B4D),
        keyText = Color(0xFFF2F2FA),
        error = Color(0xFFFF5470),
        isDark = true
    )
    AppTheme.LIGHT -> ThemeColors(
        gradientStart = Color(0xFFF7F8FC),
        gradientEnd = Color(0xFFE9ECF7),
        surface = Color(0xFFFFFFFF),
        onSurface = Color(0xFF1A1B2E),
        accent = Color(0xFF5B4BCF),
        accentSoft = Color(0xFF8B7BFF),
        dotEmpty = Color(0xFFD3D6E6),
        keyBackground = Color(0xFFFFFFFF),
        keyText = Color(0xFF1A1B2E),
        error = Color(0xFFE53E5C),
        isDark = false
    )
    AppTheme.PURPLE -> ThemeColors(
        gradientStart = Color(0xFF2D0B4E),
        gradientEnd = Color(0xFF6E1FBF),
        surface = Color(0xFF3D1466),
        onSurface = Color(0xFFF5EBFF),
        accent = Color(0xFFD68CFF),
        accentSoft = Color(0xFFB35FFF),
        dotEmpty = Color(0xFF5B2A8C),
        keyBackground = Color(0xFF4A1B7A),
        keyText = Color(0xFFF5EBFF),
        error = Color(0xFFFF6B9D),
        isDark = true
    )
    AppTheme.OCEAN -> ThemeColors(
        gradientStart = Color(0xFF021B33),
        gradientEnd = Color(0xFF0A5C8A),
        surface = Color(0xFF0D3654),
        onSurface = Color(0xFFE6F6FF),
        accent = Color(0xFF38D9FF),
        accentSoft = Color(0xFF1FA8D9),
        dotEmpty = Color(0xFF1A4D6E),
        keyBackground = Color(0xFF0F4566),
        keyText = Color(0xFFE6F6FF),
        error = Color(0xFFFF7B7B),
        isDark = true
    )
    AppTheme.SUNSET -> ThemeColors(
        gradientStart = Color(0xFF3A0F2E),
        gradientEnd = Color(0xFFE0562F),
        surface = Color(0xFF4D1530),
        onSurface = Color(0xFFFFF1E6),
        accent = Color(0xFFFFB84D),
        accentSoft = Color(0xFFFF8A5B),
        dotEmpty = Color(0xFF6B2444),
        keyBackground = Color(0xFF5C1A38),
        keyText = Color(0xFFFFF1E6),
        error = Color(0xFFFF4D6D),
        isDark = true
    )
}
