package com.nasstech.applock.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nasstech.applock.ui.theme.ThemeColors
import com.nasstech.applock.util.InstalledApp
import com.nasstech.applock.util.toImageBitmap

private enum class AppFilterTab { ALL, LOCKED }

@Composable
fun MainScreen(
    colors: ThemeColors,
    apps: List<InstalledApp>,
    lockedPackages: Set<String>,
    onToggleLock: (String, Boolean) -> Unit,
    onSettingsClick: () -> Unit,
    permissionWarningVisible: Boolean,
    onPermissionWarningClick: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(AppFilterTab.ALL) }

    val filteredApps = remember(apps, query, selectedTab, lockedPackages) {
        apps.filter { app ->
            val matchesQuery = query.isBlank() || app.label.contains(query, ignoreCase = true)
            val matchesTab = selectedTab == AppFilterTab.ALL || app.packageName in lockedPackages
            matchesQuery && matchesTab
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(colors.gradientStart, colors.gradientEnd)))
            .systemBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(20.dp, 16.dp, 20.dp, 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "تطبيقاتي",
                    color = colors.onSurface,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onSettingsClick) {
                    Icon(
                        imageVector = Icons.Filled.Settings,
                        contentDescription = "الإعدادات",
                        tint = colors.onSurface
                    )
                }
            }

            if (permissionWarningVisible) {
                PermissionWarningBanner(colors = colors, onClick = onPermissionWarningClick)
            }

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("بحث عن تطبيق…", color = colors.onSurface.copy(alpha = 0.45f)) },
                leadingIcon = {
                    Icon(Icons.Filled.Search, contentDescription = null, tint = colors.onSurface.copy(alpha = 0.6f))
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.accent,
                    unfocusedBorderColor = colors.dotEmpty,
                    focusedTextColor = colors.onSurface,
                    unfocusedTextColor = colors.onSurface,
                    cursorColor = colors.accent
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            )

            Row(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilterChip(
                    label = "كل التطبيقات",
                    selected = selectedTab == AppFilterTab.ALL,
                    colors = colors
                ) { selectedTab = AppFilterTab.ALL }
                FilterChip(
                    label = "المقفولة (${lockedPackages.size})",
                    selected = selectedTab == AppFilterTab.LOCKED,
                    colors = colors
                ) { selectedTab = AppFilterTab.LOCKED }
            }

            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(filteredApps, key = { it.packageName }) { app ->
                    AppRow(
                        app = app,
                        isLocked = app.packageName in lockedPackages,
                        colors = colors,
                        onToggle = { locked -> onToggleLock(app.packageName, locked) }
                    )
                }
            }
        }
    }
}

@Composable
private fun FilterChip(
    label: String,
    selected: Boolean,
    colors: ThemeColors,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) colors.accent else colors.surface)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else colors.onSurface.copy(alpha = 0.75f),
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun AppRow(
    app: InstalledApp,
    isLocked: Boolean,
    colors: ThemeColors,
    onToggle: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(colors.surface.copy(alpha = 0.5f))
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val bitmap = remember(app.packageName) { app.icon.toImageBitmap() }
            Image(
                bitmap = bitmap,
                contentDescription = app.label,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
            )
            Text(
                text = app.label,
                color = colors.onSurface,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(start = 14.dp)
            )
        }
        Switch(
            checked = isLocked,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(
                checkedTrackColor = colors.accent,
                checkedThumbColor = Color.White,
                uncheckedTrackColor = colors.dotEmpty
            )
        )
    }
}

@Composable
private fun PermissionWarningBanner(
    colors: ThemeColors,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(colors.error.copy(alpha = 0.15f))
            .clickable { onClick() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "صلاحية مطلوبة",
                color = colors.error,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = "فعّل صلاحية الإتاحة ليعمل القفل بشكل صحيح",
                color = colors.onSurface.copy(alpha = 0.7f),
                fontSize = 12.sp
            )
        }
        Text(
            text = "تفعيل",
            color = colors.error,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(colors.error.copy(alpha = 0.12f))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}
