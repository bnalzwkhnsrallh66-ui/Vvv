package com.nasstech.applock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.nasstech.applock.ui.MainViewModel
import com.nasstech.applock.ui.screens.MainScreen
import com.nasstech.applock.ui.screens.OnboardingScreen
import com.nasstech.applock.ui.screens.PinSetupScreen
import com.nasstech.applock.ui.screens.SettingsScreen
import com.nasstech.applock.ui.theme.AppLockTheme
import com.nasstech.applock.ui.theme.colorsFor
import com.nasstech.applock.util.AppUtils

private object Routes {
    const val ONBOARDING = "onboarding"
    const val PIN_SETUP = "pin_setup"
    const val MAIN = "main"
    const val SETTINGS = "settings"
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val uiState by viewModel.uiState.collectAsState()
            val colors = colorsFor(uiState.theme)

            AppLockTheme(appTheme = uiState.theme) {
                Surface(modifier = Modifier.fillMaxSize(), color = colors.gradientStart) {
                    val navController = rememberNavController()

                    val startDestination = when {
                        !uiState.isOnboarded -> Routes.ONBOARDING
                        !uiState.hasPin -> Routes.PIN_SETUP
                        else -> Routes.MAIN
                    }

                    AppNavHost(
                        navController = navController,
                        startDestination = startDestination,
                        viewModel = viewModel,
                        colors = colors,
                        uiState = uiState
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshAccessibilityStatus()
    }
}

@androidx.compose.runtime.Composable
private fun AppNavHost(
    navController: NavHostController,
    startDestination: String,
    viewModel: MainViewModel,
    colors: com.nasstech.applock.ui.theme.ThemeColors,
    uiState: com.nasstech.applock.ui.MainUiState
) {
    val context = androidx.compose.ui.platform.LocalContext.current

    NavHost(navController = navController, startDestination = startDestination) {
        composable(Routes.ONBOARDING) {
            OnboardingScreen(
                colors = colors,
                onFinished = {
                    viewModel.setOnboarded()
                    navController.navigate(Routes.PIN_SETUP) {
                        popUpTo(Routes.ONBOARDING) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.PIN_SETUP) {
            PinSetupScreen(
                colors = colors,
                onPinConfirmed = { pin ->
                    viewModel.setPin(pin)
                    navController.navigate(Routes.MAIN) {
                        popUpTo(Routes.PIN_SETUP) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.MAIN) {
            MainScreen(
                colors = colors,
                apps = uiState.apps,
                lockedPackages = uiState.lockedPackages,
                onToggleLock = { pkg, locked -> viewModel.toggleLock(pkg, locked) },
                onSettingsClick = { navController.navigate(Routes.SETTINGS) },
                permissionWarningVisible = !uiState.accessibilityGranted,
                onPermissionWarningClick = { AppUtils.openAccessibilitySettings(context) }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                colors = colors,
                currentTheme = uiState.theme,
                useBiometric = uiState.useBiometric,
                vibrationOn = uiState.vibrationOn,
                onThemeSelected = { viewModel.setTheme(it) },
                onChangePinClick = {
                    navController.navigate(Routes.PIN_SETUP)
                },
                onBiometricToggle = { viewModel.setUseBiometric(it) },
                onVibrationToggle = { viewModel.setVibrationOn(it) },
                onBack = { navController.popBackStack() }
            )
        }
    }
}
