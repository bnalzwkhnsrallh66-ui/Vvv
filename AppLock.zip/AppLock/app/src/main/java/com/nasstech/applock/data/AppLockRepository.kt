package com.nasstech.applock.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.MessageDigest

private val Context.dataStore by preferencesDataStore(name = "applock_prefs")

/**
 * مستودع البيانات المركزي: يخزن رمز PIN (مشفّر بـ SHA-256)،
 * قائمة التطبيقات المقفولة، الثيم المختار، وحالة الإقلاع الأول.
 */
class AppLockRepository(private val context: Context) {

    private object Keys {
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val LOCKED_PACKAGES = stringSetPreferencesKey("locked_packages")
        val THEME = stringPreferencesKey("theme")
        val ONBOARDED = booleanPreferencesKey("onboarded")
        val USE_BIOMETRIC = booleanPreferencesKey("use_biometric")
        val VIBRATION_ON = booleanPreferencesKey("vibration_on")
    }

    private fun hash(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    suspend fun setPin(pin: String) {
        context.dataStore.edit { it[Keys.PIN_HASH] = hash(pin) }
    }

    suspend fun verifyPin(pin: String): Boolean {
        val stored = context.dataStore.data.first()[Keys.PIN_HASH] ?: return false
        return stored == hash(pin)
    }

    suspend fun hasPin(): Boolean {
        return context.dataStore.data.first()[Keys.PIN_HASH] != null
    }

    val lockedPackages: Flow<Set<String>> = context.dataStore.data.map {
        it[Keys.LOCKED_PACKAGES] ?: emptySet()
    }

    suspend fun toggleLockedPackage(packageName: String, locked: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.LOCKED_PACKAGES]?.toMutableSet() ?: mutableSetOf()
            if (locked) current.add(packageName) else current.remove(packageName)
            prefs[Keys.LOCKED_PACKAGES] = current
        }
    }

    suspend fun getLockedPackagesSnapshot(): Set<String> {
        return context.dataStore.data.first()[Keys.LOCKED_PACKAGES] ?: emptySet()
    }

    val theme: Flow<String> = context.dataStore.data.map {
        it[Keys.THEME] ?: "dark"
    }

    suspend fun setTheme(themeId: String) {
        context.dataStore.edit { it[Keys.THEME] = themeId }
    }

    val isOnboarded: Flow<Boolean> = context.dataStore.data.map {
        it[Keys.ONBOARDED] ?: false
    }

    suspend fun setOnboarded(value: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDED] = value }
    }

    val useBiometric: Flow<Boolean> = context.dataStore.data.map {
        it[Keys.USE_BIOMETRIC] ?: false
    }

    suspend fun setUseBiometric(value: Boolean) {
        context.dataStore.edit { it[Keys.USE_BIOMETRIC] = value }
    }

    val vibrationOn: Flow<Boolean> = context.dataStore.data.map {
        it[Keys.VIBRATION_ON] ?: true
    }

    suspend fun setVibrationOn(value: Boolean) {
        context.dataStore.edit { it[Keys.VIBRATION_ON] = value }
    }
}
