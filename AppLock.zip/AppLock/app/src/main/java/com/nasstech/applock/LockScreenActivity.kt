package com.nasstech.applock

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import com.nasstech.applock.ui.MainViewModel
import com.nasstech.applock.ui.screens.LockUnlockScreen
import com.nasstech.applock.ui.theme.AppLockTheme
import com.nasstech.applock.ui.theme.colorsFor

/**
 * شاشة قفل مستقلة (singleInstance) تظهر فوق التطبيق المستهدف.
 * عند النجاح، تُسجَّل فترة سماح مؤقتة (UnlockSessionCache) وتُغلق الشاشة
 * فيعود المستخدم تلقائيًا إلى التطبيق الذي كان يحاول فتحه.
 */
class LockScreenActivity : FragmentActivity() {

    private val viewModel: MainViewModel by viewModels()

    companion object {
        const val EXTRA_TARGET_PACKAGE = "extra_target_package"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val targetPackage = intent.getStringExtra(EXTRA_TARGET_PACKAGE)

        setContent {
            val uiState by viewModel.uiState.collectAsState()
            val colors = colorsFor(uiState.theme)

            AppLockTheme(appTheme = uiState.theme) {
                Surface(modifier = Modifier.fillMaxSize(), color = colors.gradientStart) {
                    LockUnlockScreen(
                        colors = colors,
                        useBiometric = uiState.useBiometric,
                        activity = this,
                        onVerifyPin = { pin -> viewModel.verifyPin(pin) },
                        onUnlocked = {
                            if (targetPackage != null) {
                                UnlockSessionCache.markUnlocked(targetPackage)
                            }
                            finish()
                        }
                    )
                }
            }
        }
    }

    /**
     * إذا ضغط المستخدم زر الرجوع بدون إدخال الرمز الصحيح، نعتبر ذلك رفضًا
     * للدخول ونرسله إلى الشاشة الرئيسية (Home) بدل تركه عالقًا أو تركه
     * يدخل التطبيق المقفول بدون تحقق.
     */
    override fun onBackPressed() {
        goHome()
    }

    private fun goHome() {
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(homeIntent)
        finish()
    }
}
