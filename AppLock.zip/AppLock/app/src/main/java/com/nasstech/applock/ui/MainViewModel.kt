package com.nasstech.applock.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nasstech.applock.AppLockApplication
import com.nasstech.applock.ui.theme.AppTheme
import com.nasstech.applock.util.AppUtils
import com.nasstech.applock.util.InstalledApp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

data class MainUiState(
    val isLoading: Boolean = true,
    val isOnboarded: Boolean = false,
    val hasPin: Boolean = false,
    val apps: List<InstalledApp> = emptyList(),
    val lockedPackages: Set<String> = emptySet(),
    val theme: AppTheme = AppTheme.DARK,
    val useBiometric: Boolean = false,
    val vibrationOn: Boolean = true,
    val accessibilityGranted: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as AppLockApplication).repository

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        loadInstalledApps()
        observePreferences()
    }

    private fun loadInstalledApps() {
        viewModelScope.launch {
            val apps = AppUtils.getInstalledApps(getApplication())
            _uiState.value = _uiState.value.copy(apps = apps, isLoading = false)
        }
    }

    private fun observePreferences() {
        viewModelScope.launch {
            repository.isOnboarded.collectLatest { onboarded ->
                _uiState.value = _uiState.value.copy(isOnboarded = onboarded)
            }
        }
        viewModelScope.launch {
            repository.lockedPackages.collectLatest { locked ->
                _uiState.value = _uiState.value.copy(lockedPackages = locked)
            }
        }
        viewModelScope.launch {
            repository.theme.collectLatest { themeId ->
                _uiState.value = _uiState.value.copy(theme = AppTheme.fromId(themeId))
            }
        }
        viewModelScope.launch {
            repository.useBiometric.collectLatest { value ->
                _uiState.value = _uiState.value.copy(useBiometric = value)
            }
        }
        viewModelScope.launch {
            repository.vibrationOn.collectLatest { value ->
                _uiState.value = _uiState.value.copy(vibrationOn = value)
            }
        }
        viewModelScope.launch {
            val hasPin = repository.hasPin()
            _uiState.value = _uiState.value.copy(hasPin = hasPin)
        }
    }

    fun refreshAccessibilityStatus() {
        val granted = AppUtils.isAccessibilityServiceEnabled(getApplication())
        _uiState.value = _uiState.value.copy(accessibilityGranted = granted)
    }

    fun setOnboarded() {
        viewModelScope.launch { repository.setOnboarded(true) }
    }

    fun setPin(pin: String) {
        viewModelScope.launch {
            repository.setPin(pin)
            _uiState.value = _uiState.value.copy(hasPin = true)
        }
    }

    suspend fun verifyPin(pin: String): Boolean = repository.verifyPin(pin)

    fun toggleLock(packageName: String, locked: Boolean) {
        viewModelScope.launch {
            repository.toggleLockedPackage(packageName, locked)
        }
    }

    fun setTheme(theme: AppTheme) {
        viewModelScope.launch { repository.setTheme(theme.id) }
    }

    fun setUseBiometric(value: Boolean) {
        viewModelScope.launch { repository.setUseBiometric(value) }
    }

    fun setVibrationOn(value: Boolean) {
        viewModelScope.launch { repository.setVibrationOn(value) }
    }
}
