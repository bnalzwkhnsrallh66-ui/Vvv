package com.nasstech.applock.ui.screens

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity
import com.nasstech.applock.ui.theme.ThemeColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * شاشة فتح القفل المعروضة فوق التطبيق المستهدف.
 * تدعم PIN دائمًا، وتدعم البصمة اختياريًا إذا كانت مفعّلة ومتاحة على الجهاز.
 */
@Composable
fun LockUnlockScreen(
    colors: ThemeColors,
    useBiometric: Boolean,
    activity: FragmentActivity?,
    onVerifyPin: suspend (String) -> Boolean,
    onUnlocked: () -> Unit
) {
    var showError by remember { mutableStateOf(false) }
    var errorTick by remember { mutableStateOf(0) }
    var biometricAvailable by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(errorTick) {
        if (errorTick > 0) {
            showError = true
            delay(900)
            showError = false
        }
    }

    LaunchedEffect(useBiometric, activity) {
        biometricAvailable = useBiometric && activity != null && isBiometricReady(activity)
        if (biometricAvailable && activity != null) {
            showBiometricPrompt(activity, onSuccess = onUnlocked)
        }
    }

    PinEntryScreen(
        title = "أدخل الرمز السري",
        subtitle = "هذا التطبيق محمي برمز PIN",
        colors = colors,
        showBiometric = biometricAvailable,
        showError = showError,
        errorMessage = "رمز خاطئ",
        onComplete = { pin ->
            scope.launch {
                val isCorrect = onVerifyPin(pin)
                if (isCorrect) {
                    onUnlocked()
                } else {
                    errorTick++
                }
            }
        },
        onBiometricClick = {
            if (activity != null) {
                showBiometricPrompt(activity, onSuccess = onUnlocked)
            }
        }
    )
}

private fun isBiometricReady(activity: FragmentActivity): Boolean {
    val manager = BiometricManager.from(activity)
    return manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
        BiometricManager.BIOMETRIC_SUCCESS
}

private fun showBiometricPrompt(activity: FragmentActivity, onSuccess: () -> Unit) {
    val executor = androidx.core.content.ContextCompat.getMainExecutor(activity)
    val callback = object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            super.onAuthenticationSucceeded(result)
            onSuccess()
        }
    }
    val prompt = BiometricPrompt(activity, executor, callback)
    val promptInfo = BiometricPrompt.PromptInfo.Builder()
        .setTitle("التحقق من الهوية")
        .setSubtitle("استخدم بصمتك لفتح التطبيق")
        .setNegativeButtonText("استخدام الرمز السري")
        .build()
    prompt.authenticate(promptInfo)
}
