package com.nasstech.applock.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * خدمة الإتاحة تُعاد تفعيلها تلقائيًا من نظام أندرويد بعد إعادة التشغيل
 * إذا كانت مفعّلة مسبقًا من إعدادات النظام، لذلك هذا المستقبل لا يحتاج
 * فعليًا لإعادة تشغيل أي شيء يدويًا، لكنه موجود لأي تهيئة مستقبلية
 * (مثل تحديث الكاش أو تسجيل حدث).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // مكان مخصص لأي تهيئة مستقبلية عند الإقلاع
        }
    }
}
