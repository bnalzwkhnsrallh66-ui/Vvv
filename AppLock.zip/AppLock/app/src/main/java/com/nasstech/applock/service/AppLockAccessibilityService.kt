package com.nasstech.applock.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.nasstech.applock.AppLockApplication
import com.nasstech.applock.LockScreenActivity
import com.nasstech.applock.UnlockSessionCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * خدمة إتاحة تستمع لتغييرات نوافذ النظام (typeWindowStateChanged) لمعرفة أي تطبيق
 * انتقل المستخدم إليه. إذا كان هذا التطبيق ضمن قائمة المقفولة ولم يُفتح حديثًا
 * (خارج فترة السماح)، يتم إطلاق شاشة القفل فوقه فورًا.
 */
class AppLockAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var lastForegroundPackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val packageName = event.packageName?.toString() ?: return
        if (packageName == applicationContext.packageName) return
        if (packageName == lastForegroundPackage) return

        lastForegroundPackage = packageName

        serviceScope.launch {
            val app = applicationContext as? AppLockApplication ?: return@launch
            val lockedPackages = app.repository.getLockedPackagesSnapshot()

            if (packageName in lockedPackages && !UnlockSessionCache.isRecentlyUnlocked(packageName)) {
                launchLockScreen(packageName)
            }
        }
    }

    private fun launchLockScreen(targetPackage: String) {
        val intent = Intent(this, LockScreenActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(LockScreenActivity.EXTRA_TARGET_PACKAGE, targetPackage)
        }
        startActivity(intent)
    }

    override fun onInterrupt() {
        // لا حاجة لإجراء خاص هنا
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        lastForegroundPackage = null
    }
}
