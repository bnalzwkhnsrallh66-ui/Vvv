package com.nasstech.applock.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.TextStyle

val LocalThemeColors = compositionLocalOf { colorsFor(AppTheme.DARK) }

@Composable
fun AppLockTheme(
    appTheme: AppTheme = AppTheme.DARK,
    content: @Composable () -> Unit
) {
    val themeColors = colorsFor(appTheme)

    val colorScheme = if (themeColors.isDark) {
        darkColorScheme(
            primary = themeColors.accent,
            secondary = themeColors.accentSoft,
            background = themeColors.gradientStart,
            surface = themeColors.surface,
            onBackground = themeColors.onSurface,
            onSurface = themeColors.onSurface,
            error = themeColors.error
        )
    } else {
        lightColorScheme(
            primary = themeColors.accent,
            secondary = themeColors.accentSoft,
            background = themeColors.gradientStart,
            surface = themeColors.surface,
            onBackground = themeColors.onSurface,
            onSurface = themeColors.onSurface,
            error = themeColors.error
        )
    }

    CompositionLocalProvider(LocalThemeColors provides themeColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = MaterialTheme.typography,
            content = content
        )
    }
}
